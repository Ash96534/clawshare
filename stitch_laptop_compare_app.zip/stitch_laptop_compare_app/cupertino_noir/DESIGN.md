```markdown
# High-End Desktop Experience: Design System Documentation

## 1. Overview & Creative North Star
**Creative North Star: "The Obsidian Gallery"**

This design system transcends the typical "utility app" aesthetic, treating the Windows desktop environment as a high-end, editorial gallery. By combining the precision of Apple’s design language with the expansive power of a desktop application, we create an experience that feels curated rather than constructed. 

The system moves beyond a "flat" interface by leveraging **intentional asymmetry** and **tonal depth**. We reject the "boxed-in" feeling of traditional Windows software in favor of an expansive, breathable layout where content is anchored by heavy typographic scales and sophisticated layering.

---

## 2. Colors & Surface Philosophy

The color palette is built on deep obsidian tones, designed to make the hardware bezel disappear and the content pop with cinematic clarity.

### Color Tokens
- **Background (Primary):** `#131315` (The Foundation)
- **Primary Accent:** `#aac7ff` (A soft, high-end blue that vibrates less than standard electric blue)
- **Secondary Accent:** `#4edea3` (A mint-leaning green for success/positive metrics)
- **Tertiary Accent:** `#ffb3ad` (A sophisticated coral-red for errors and critical alerts)
- **Neutral/Surface:** `#1f1f21` (Container low), `#2a2a2c` (Container high)

### The "No-Line" Rule
To achieve a signature premium feel, **1px solid borders are strictly prohibited for sectioning.** Boundaries must be defined through:
1.  **Background Shifts:** Transitioning from `surface` to `surface-container-low`.
2.  **Tonal Transitions:** Using depth to imply separation.
3.  **Negative Space:** Using the spacing scale to let the eye define groups.

### The "Glass & Gradient" Rule
Floating elements (modals, popovers, navigation sidebars) should utilize **Glassmorphism**. 
- **Effect:** `surface-container` color at 70% opacity + 20px-30px Backdrop Blur.
- **Soul:** Main CTAs should use a subtle linear gradient from `primary` to `primary-container` (top-left to bottom-right) to avoid the "flat-button" look.

---

## 3. Typography: Editorial Authority

We use **Inter** (as the Windows-native equivalent to San Francisco) to provide a clean, technical, yet humanist feel.

| Role | Size | Weight | Usage |
| :--- | :--- | :--- | :--- |
| **Display-LG** | 3.5rem | 700 (Bold) | Hero metrics, large dashboard titles. |
| **Headline-MD** | 1.75rem | 600 (Semi-Bold)| Section headers. |
| **Title-SM** | 1.0rem | 500 (Medium) | Card titles, modal headers. |
| **Body-MD** | 0.875rem| 400 (Regular)| General content and descriptions. |
| **Label-MD** | 0.75rem | 600 (Bold) | Micro-copy, all-caps metadata. |

**Editorial Note:** Use `Display-LG` sparingly to create a "starting point" for the eye on every screen. High contrast between large headlines and small labels is the key to an expensive look.

---

## 4. Elevation & Depth

We reject traditional drop shadows in favor of **Tonal Layering**.

*   **The Layering Principle:** Stack surfaces like physical sheets of glass. 
    *   *Base:* `surface` (`#131315`)
    *   *Section:* `surface-container-low` (`#1b1b1d`)
    *   *Card:* `surface-container` (`#1f1f21`)
*   **Ambient Shadows:** For floating elements only. Use a 32px blur with 6% opacity. The shadow color should be `surface-container-lowest` to feel like an occlusion of light rather than a "black smudge."
*   **The Ghost Border:** If a visual anchor is needed, use `outline-variant` at 15% opacity. This creates a "glimmer" on the edge that suggests a border without the heaviness of a solid line.

---

## 5. Components

### Buttons
*   **Primary:** Gradient fill (`primary` to `primary-container`), 12px roundedness (`md`). White text for maximum legibility.
*   **Secondary:** No fill. `Ghost Border` (15% opacity outline) with `primary` colored text.
*   **Tertiary:** Text-only, using `label-md` for a precise, "utility" feel.

### Cards & Lists
*   **Rule:** Forbid divider lines.
*   **Implementation:** Separate list items using 8px of vertical padding. On hover, change the background to `surface-bright`.
*   **Cards:** Use `xl` (1.5rem) rounded corners. Content inside cards should have generous internal padding (24px minimum).

### Input Fields
*   **Style:** `surface-container-highest` background. No border.
*   **State:** On focus, add a 1px `primary` ghost border (20% opacity) and a subtle inner glow.
*   **Labels:** Always use `label-sm` in `secondary-text` color, placed 8px above the field.

### System Trays (Specific to LaptopComp)
*   **Resource Gauges:** Use thin, circular progress rings instead of bars. Use the `secondary` (Green) color with a `surface-container-high` track.

---

## 6. Do’s and Don’ts

### Do:
*   **Embrace Asymmetry:** Let a large headline sit on the left with significant empty space on the right to create "breathing room."
*   **Use SF-Style Iconography:** Icons should have a consistent line weight (Medium) and rounded terminals to match the typography.
*   **Layer with Intent:** Ensure that the most interactive elements are on the "highest" tonal layer.

### Don’t:
*   **Don't use pure black text:** Even on white backgrounds, use `on-surface`.
*   **Don't use 100% opacity borders:** It breaks the "Obsidian Gallery" illusion and makes the app look like a standard Windows 10 utility.
*   **Don't crowd the UI:** If a screen feels busy, increase the background-to-content ratio. Premium design is defined by what you leave out.
*   **Don't use standard Windows "Shadows":** They are often too dark and tight. Always opt for the Ambient Shadow spec defined in Section 4.

---
**Director's Closing Note:** 
This system is not a set of constraints; it is a philosophy. Every pixel should feel like it was placed with a pair of jeweler's tweezers. When in doubt, add more space, reduce the border opacity, and let the typography do the heavy lifting.```