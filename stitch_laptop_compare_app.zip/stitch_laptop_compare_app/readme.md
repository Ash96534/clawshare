# LaptopComp - Laptop Comparison & Price Tracker

A fully self-contained laptop comparison tool with Amazon price tracking, custom scoring system, and AI-powered recommendations.

## Features

### 🔄 4-Way Comparison
- Side-by-side comparison of up to 4 laptops
- Automatic winner highlighting in each category
- Detailed specification breakdown

### 💡 Smart Alternatives
Three types of suggestions for any laptop:
1. **Better Value** - Similar specs, better value for money
2. **Cheaper Options** - Lower price, similar performance
3. **Premium Upgrades** - Higher cost, significantly better specs

### 📊 Custom Scoring System
Performance scores based on:
- CPU performance (cores, threads, clock speed, TDP)
- GPU capability (VRAM, type, performance tier)
- Memory and storage
- Display quality
- Portability (weight, thickness)
- Battery efficiency

### 💰 Price Tracking
- Historical price tracking
- Price trend analysis
- Best time to buy recommendations

### 🤖 AI Features (via OpenRouter)
- Web-search enabled recommendations
- Price insights and deal detection
- Comparison recommendations by use case

### 📦 Local Database
- All data stored locally in SQLite
- Fast retrieval for previously analyzed laptops
- Cached CPU/GPU benchmark scores

## Installation

```bash
# Clone the repository
git clone <repository-url>
cd lapicomp

# Run setup
python setup.py

# Or manually install dependencies
pip install -r requirements.txt
```

## Configuration

1. Get a free API key from [OpenRouter](https://openrouter.ai) (optional, for AI features)
2. Edit `.env` file:
```
OPENROUTER_API_KEY=your_api_key_here
```

## Usage

### Interactive Mode
```bash
python -m src.main
```

### Command Line
```bash
# Search for laptops
python -m src.main search "gaming laptop RTX 4060"

# Compare laptops
python -m src.main compare 1 2 3 4

# Find alternatives
python -m src.main alternatives 1

# Score a laptop
python -m src.main score 1

# View price history
python -m src.main history 1

# Browse database
python -m src.main browse

# Database stats
python -m src.main stats
```

## Project Structure

```
lapicomp/
├── src/
│   ├── main.py           # Main application entry
│   ├── core/
│   │   ├── scoring.py    # Custom scoring system
│   │   ├── comparison.py # 4-way comparison engine
│   │   └── alternatives.py # Alternative finder
│   ├── db/
│   │   └── __init__.py   # SQLite database
│   ├── services/
│   │   └── openrouter.py # AI/LLM integration
│   ├── scrapers/
│   │   └── amazon.py     # Amazon data scraper
│   └── utils/            # Utility functions
├── data/                 # Local database storage
├── requirements.txt
├── setup.py
└── README.md
```

## Scoring System

### Performance Score (30%)
- CPU: cores, threads, boost clock, TDP, cache
- GPU: VRAM, type, performance tier
- RAM: capacity
- Storage: capacity and type

### Value Score (25%)
- Performance per dollar ratio
- Spec bonuses (RAM, storage, display)

### Portability Score (15%)
- Weight
- Thickness
- Battery life estimate

### Display Score (10%)
- Resolution
- Panel type
- Refresh rate

### Battery Score (10%)
- Capacity
- TDP-based efficiency estimate

### Build Score (10%)
- Material quality
- Construction indicators

## Database Schema

- **laptops** - Main laptop information
- **price_history** - Price tracking over time
- **laptop_specs** - Detailed specifications
- **cpu_scores** - CPU benchmark data
- **gpu_scores** - GPU benchmark data
- **laptop_scores** - Calculated scores
- **comparisons** - Saved comparison sessions

## License

MIT License
